package com.example.autoscrollvideo

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var serviceStatusText: TextView
    private lateinit var runStatusText: TextView
    private lateinit var durationInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var speedSpinner: Spinner
    private lateinit var pauseButton: Button

    private val statusUpdater = object : Runnable {
        override fun run() {
            refreshStatus()
            runStatusText.postDelayed(this, 500L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        serviceStatusText = findViewById(R.id.serviceStatusText)
        runStatusText = findViewById(R.id.runStatusText)
        durationInput = findViewById(R.id.durationInput)
        intervalInput = findViewById(R.id.intervalInput)
        speedSpinner = findViewById(R.id.speedSpinner)
        pauseButton = findViewById(R.id.pauseButton)

        val speedOptions = listOf("Cepat", "Normal", "Lambat")
        speedSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            speedOptions
        )
        speedSpinner.setSelection(1)

        findViewById<Button>(R.id.openAccessibilityButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.startButton).setOnClickListener {
            startScrolling()
        }

        pauseButton.setOnClickListener {
            val service = AutoScrollAccessibilityService.instance
            if (service == null) {
                showEnableServiceMessage()
            } else {
                service.pauseOrResume()
                refreshStatus()
            }
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            AutoScrollAccessibilityService.instance?.stopAutoScroll()
            refreshStatus()
        }
    }

    override fun onResume() {
        super.onResume()
        runStatusText.removeCallbacks(statusUpdater)
        runStatusText.post(statusUpdater)
    }

    override fun onPause() {
        runStatusText.removeCallbacks(statusUpdater)
        super.onPause()
    }

    private fun startScrolling() {
        val service = AutoScrollAccessibilityService.instance
        if (service == null) {
            showEnableServiceMessage()
            return
        }

        val durationMinutes = durationInput.text.toString().replace(',', '.').toDoubleOrNull()
        val intervalSeconds = intervalInput.text.toString().replace(',', '.').toDoubleOrNull()

        if (durationMinutes == null || durationMinutes <= 0.0) {
            durationInput.error = "Masukkan durasi lebih dari 0 menit"
            return
        }

        if (intervalSeconds == null || intervalSeconds < 0.5) {
            intervalInput.error = "Interval minimal 0,5 detik"
            return
        }

        val totalDurationMs = (durationMinutes * 60_000.0).toLong()
        val intervalMs = (intervalSeconds * 1_000.0).toLong()
        val swipeDurationMs = when (speedSpinner.selectedItemPosition) {
            0 -> 250L
            2 -> 800L
            else -> 450L
        }

        service.startAutoScroll(totalDurationMs, intervalMs, swipeDurationMs)
        Toast.makeText(this, "Auto scroll mulai dalam 3 detik", Toast.LENGTH_LONG).show()
        refreshStatus()
    }

    private fun showEnableServiceMessage() {
        Toast.makeText(
            this,
            "Aktifkan Auto Scroll Video di menu Accessibility terlebih dahulu.",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun refreshStatus() {
        val service = AutoScrollAccessibilityService.instance
        serviceStatusText.text = if (service == null) "Belum aktif" else "Aktif"

        if (service == null) {
            runStatusText.text = "Siap"
            pauseButton.text = "Pause"
            return
        }

        val remainingSeconds = service.remainingTimeMs() / 1_000.0
        val remainingText = formatRemaining(remainingSeconds)

        when (service.currentState()) {
            AutoScrollAccessibilityService.RunState.IDLE -> {
                runStatusText.text = "Siap"
                pauseButton.text = "Pause"
            }
            AutoScrollAccessibilityService.RunState.WAITING -> {
                runStatusText.text = "Mulai dalam 3 detik..."
                pauseButton.text = "Pause"
            }
            AutoScrollAccessibilityService.RunState.RUNNING -> {
                runStatusText.text = "Berjalan - sisa $remainingText"
                pauseButton.text = "Pause"
            }
            AutoScrollAccessibilityService.RunState.PAUSED -> {
                runStatusText.text = "Dijeda - sisa $remainingText"
                pauseButton.text = "Resume"
            }
            AutoScrollAccessibilityService.RunState.FINISHED -> {
                runStatusText.text = "Selesai"
                pauseButton.text = "Pause"
            }
        }
    }

    private fun formatRemaining(seconds: Double): String {
        val total = seconds.toLong().coerceAtLeast(0L)
        val minutes = total / 60
        val secs = total % 60
        return String.format(Locale.getDefault(), "%02d:%02d", minutes, secs)
    }
}
