package com.example.autoscrollvideo

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import kotlin.math.max

class AutoScrollAccessibilityService : AccessibilityService() {

    enum class RunState { IDLE, WAITING, RUNNING, PAUSED, FINISHED }

    companion object {
        @Volatile
        var instance: AutoScrollAccessibilityService? = null
            private set
    }

    private val handler = Handler(Looper.getMainLooper())
    private var state = RunState.IDLE
    private var intervalMs = 5_000L
    private var swipeDurationMs = 450L
    private var remainingMs = 0L
    private var endAtElapsed = 0L

    private val scrollRunnable = object : Runnable {
        override fun run() {
            if (state != RunState.RUNNING) return

            val now = SystemClock.elapsedRealtime()
            if (now >= endAtElapsed) {
                finishRun()
                return
            }

            performSwipe()
            handler.postDelayed(this, intervalMs)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun startAutoScroll(totalDurationMs: Long, intervalMs: Long, swipeDurationMs: Long) {
        handler.removeCallbacksAndMessages(null)
        this.intervalMs = intervalMs.coerceAtLeast(500L)
        this.swipeDurationMs = swipeDurationMs.coerceIn(150L, 1_500L)
        this.remainingMs = totalDurationMs.coerceAtLeast(1_000L)
        state = RunState.WAITING

        handler.postDelayed({
            if (state != RunState.WAITING) return@postDelayed
            state = RunState.RUNNING
            endAtElapsed = SystemClock.elapsedRealtime() + remainingMs
            performSwipe()
            handler.postDelayed(scrollRunnable, this.intervalMs)
        }, 3_000L)
    }

    fun pauseOrResume() {
        when (state) {
            RunState.RUNNING -> pause()
            RunState.PAUSED -> resume()
            else -> Unit
        }
    }

    fun stopAutoScroll() {
        handler.removeCallbacksAndMessages(null)
        remainingMs = 0L
        state = RunState.IDLE
    }

    fun currentState(): RunState = state

    fun remainingTimeMs(): Long {
        return when (state) {
            RunState.RUNNING -> max(0L, endAtElapsed - SystemClock.elapsedRealtime())
            RunState.PAUSED, RunState.WAITING -> remainingMs
            else -> 0L
        }
    }

    private fun pause() {
        if (state != RunState.RUNNING) return
        remainingMs = max(0L, endAtElapsed - SystemClock.elapsedRealtime())
        handler.removeCallbacks(scrollRunnable)
        state = RunState.PAUSED
    }

    private fun resume() {
        if (state != RunState.PAUSED || remainingMs <= 0L) return
        state = RunState.RUNNING
        endAtElapsed = SystemClock.elapsedRealtime() + remainingMs
        performSwipe()
        handler.postDelayed(scrollRunnable, intervalMs)
    }

    private fun finishRun() {
        handler.removeCallbacks(scrollRunnable)
        remainingMs = 0L
        state = RunState.FINISHED
    }

    private fun performSwipe() {
        val metrics = resources.displayMetrics
        val x = metrics.widthPixels * 0.5f
        val startY = metrics.heightPixels * 0.78f
        val endY = metrics.heightPixels * 0.28f

        val path = Path().apply {
            moveTo(x, startY)
            lineTo(x, endY)
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, swipeDurationMs))
            .build()

        dispatchGesture(gesture, null, null)
    }
}
