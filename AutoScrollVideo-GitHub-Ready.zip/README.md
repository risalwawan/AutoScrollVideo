# Auto Scroll Video

Aplikasi Android sederhana untuk melakukan swipe/scroll otomatis dengan **Accessibility Service**.

## Fitur

- Tentukan durasi total auto scroll dalam menit.
- Tentukan interval antar-scroll dalam detik.
- Pilih kecepatan swipe: Cepat, Normal, atau Lambat.
- Tombol Start, Pause/Resume, dan Stop.
- Jeda 3 detik setelah Start agar pengguna sempat berpindah ke aplikasi video.
- Otomatis berhenti ketika durasi total habis.

## Cara memakai

1. Install aplikasi.
2. Buka **Auto Scroll Video**.
3. Tekan **Buka Pengaturan Accessibility**.
4. Aktifkan layanan **Auto Scroll Video**.
5. Kembali ke aplikasi dan atur durasi, interval, serta kecepatan.
6. Tekan **Start** lalu buka aplikasi video dalam 3 detik.
7. Gunakan Pause/Resume atau Stop dari aplikasi Auto Scroll Video bila diperlukan.

> Gunakan automasi hanya pada aplikasi dan layanan yang mengizinkannya serta patuhi ketentuan platform yang digunakan.

## Build dengan Android Studio

1. Buka folder proyek di Android Studio.
2. Pastikan JDK 17 tersedia.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build APK(s)**.
5. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Build dari terminal

```bash
gradle assembleDebug
```

APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions

Workflow `.github/workflows/android-build.yml` akan otomatis menyiapkan Gradle 8.9, melakukan build APK setiap push ke branch `main`, lalu menyediakan `app-debug.apk` sebagai artifact.

## Teknologi

- Kotlin
- Android Accessibility Service
- AndroidX / Material Components
- Min SDK 24
- Target SDK 35
