@echo off
where gradle >nul 2>nul
if %errorlevel% neq 0 (
  echo Gradle 8.9 belum tersedia. Install Gradle 8.9 atau buka proyek melalui Android Studio.
  exit /b 1
)
gradle %*
